/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.p2.cajablanca;
import ppss.p2.cajablanca.IsbnInvalidoException;
import ppss.p2.cajablanca.SocioInvalidoException;
import ppss.p2.cajablanca.JDBCException;
/**
 *
 * @author ppss
 */
class IOperacionBO {

    void realizaReserva(String socio, String bn) throws IsbnInvalidoException, SocioInvalidoException, JDBCException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
