package ppss.matriculacion.dao;

import java.util.List;

import ppss.matriculacion.to.AsignaturaTO;

public class JDBCAsignaturaDAO implements IAsignaturaDAO {

	public void addAsignatura(AsignaturaTO asignatura) throws DAOException {
		// TODO Auto-generated method stub

	}

	public AsignaturaTO buscaAsignatura(String nombre) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	public void delAsignatura(String cod) throws DAOException {
		// TODO Auto-generated method stub

	}

	public AsignaturaTO getAsignatura(int cod) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<AsignaturaTO> getAsignaturas() throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

}
